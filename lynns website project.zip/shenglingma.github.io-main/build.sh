bundle add webrick

bundle exec jekyll server
